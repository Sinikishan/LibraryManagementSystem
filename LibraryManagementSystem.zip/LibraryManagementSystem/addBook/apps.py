from django.apps import AppConfig


class AddbookConfig(AppConfig):
    name = 'addBook'
