from django.contrib import admin
from viewBooks.models import Book

# Register your models here.
admin.site.register(Book)
