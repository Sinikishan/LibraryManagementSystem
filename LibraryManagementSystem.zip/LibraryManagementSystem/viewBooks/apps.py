from django.apps import AppConfig


class ViewbooksConfig(AppConfig):
    name = 'viewBooks'
