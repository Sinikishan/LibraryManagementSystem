from django.contrib import admin
from borrowBook.models import Borrower

# Register your models here.
admin.site.register(Borrower)
