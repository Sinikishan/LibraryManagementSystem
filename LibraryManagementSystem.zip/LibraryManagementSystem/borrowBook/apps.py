from django.apps import AppConfig


class BorrowbookConfig(AppConfig):
    name = 'borrowBook'
